Sakila is a sample database file used for various exercises.

